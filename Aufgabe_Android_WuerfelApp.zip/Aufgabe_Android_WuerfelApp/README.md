# Aufgabe
In dieser Aufgabe soll eine Würfel App programmiert werden 🎲

<img height="300" src="https://user-images.githubusercontent.com/101095654/220297724-0811bffd-da29-4662-82a1-a519b427d815.png">

Lade das Projekt in Android Studio. Es handelt sich um ein leeres Projekt, in dem nur die Würfelbilder schon enthalten sind. 
Die Würfelbilder findest du im Ressource Manager.

Baue die Würfel App nach:

- Die App enthält ein einfaches Layout, welches sich dem Tag und Nacht Modus anpasst
- Das Layout enthält mindestens eine Image View und einen Button.
- Die App enthält eine `Wuerfel` Klasse, mit der du ein Würfel Objekt erzeugen kannst
- Die `Wuerfel` Klasse enthält eine Funktion `wurf()`, mit der der Würfel eine beliebige Zahl würfelt 
- Über den Button wird der Wurf ausgeführt und die ImageView zeigt das entsprechende Bild

Baue die App gerne weiter aus und verschönere sie oder baue weitere Funktionen ein, z.b. was passiert wenn man eine 6 würfelt?

Viel Erfolg 😎
