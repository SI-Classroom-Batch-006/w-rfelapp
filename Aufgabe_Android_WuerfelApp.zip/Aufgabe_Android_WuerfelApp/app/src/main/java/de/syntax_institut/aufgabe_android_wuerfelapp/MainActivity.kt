package de.syntax_institut.aufgabe_android_wuerfelapp

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var button: Button
    private lateinit var imageView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button = findViewById(R.id.button)
        imageView = findViewById(R.id.imageView)

        // Würfel beim Start erzeugen
        val wuerfel = Wuerfel()

        // Button-Click Listener hinzufügen
        button.setOnClickListener {
            // Würfel werfen
            val nummer = wuerfel.wurf()
            // Image View setzen
            imageView.setImageResource(getResourceIdForNumber(nummer))
        }
    }

    // Liefert die Resource ID für eine Würfelzahl
    private fun getResourceIdForNumber(nummer: Int): Int {
        return when(nummer) {
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            6 -> R.drawable.dice_6
            else -> R.drawable.dice_1
        }
    }

    // Würfel-Klasse
    class Wuerfel {
        // Würfelt eine Zahl zwischen 1 und 6
        fun wurf(): Int {
            return (1..6).random()
        }
    }
}